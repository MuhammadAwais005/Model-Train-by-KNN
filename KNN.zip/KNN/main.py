#Iris Dataset Trained
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
# from datai.auto_plot import AutoPlot
file = r'C:\Users\92348\Desktop\KNN\Iris.csv'
df = pd.read_csv(file)
df = pd.DataFrame(df)
print(df.head())

print(df.shape)
# AutoPlot.auto_plot(df)
x = df.drop('Id', axis='columns')
x = x.drop('Species', axis='columns')
y = df['Species']
x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=7)

# print(x_test, y_test)

model = KNeighborsClassifier()

model.fit(x_train, y_train)

y_pred = model.predict(x_test)

score = accuracy_score(y_true=y_test, y_pred=y_pred)

print(score)

def test(df):
    label = model.predict(df)
    print(label)

df = [[4.6, 3.1, 1.5, 0.2]]
test(df)